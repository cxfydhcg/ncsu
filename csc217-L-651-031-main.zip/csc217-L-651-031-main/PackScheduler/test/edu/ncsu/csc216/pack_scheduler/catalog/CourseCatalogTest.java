/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.catalog;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.Before;
import org.junit.Test;




/**
 * test methods in courseCatalog
 * @author Xufeng Ce
 * @author Shiv Patel
 *
 */
public class CourseCatalogTest {
	/** Course name */
	private static final String NAME = "CSC 216";
	/** Course title */
	private static final String TITLE = "Software Development Fundamentals";
	/** Course section */
	private static final String SECTION = "001";
	/** Course credits */
	private static final int CREDITS = 3;
	/** Course instructor id */
	private static final String INSTRUCTOR_ID = "sesmith5";
	/** Course meeting days */
	private static final String MEETING_DAYS = "TH";
	/** Course start time */
	private static final int START_TIME = 1330;
	/** Course end time */
	private static final int END_TIME = 1445;
	/** Valid test File */
	private final String validTestFile = "test-files/course_records.txt";
	
	
	/**
	 * Resets course_records.txt for use in other tests.
	 * @throws Exception if something fails during setup.
	 */
	@Before
	public void setUp() throws Exception {		
		//Reset student_records.txt so that it's fine for other needed tests
		Path sourcePath = FileSystems.getDefault().getPath("test-files", "starter_course_records.txt");
		Path destinationPath = FileSystems.getDefault().getPath("test-files", "course_records.txt");
		try {
			Files.deleteIfExists(destinationPath);
			Files.copy(sourcePath, destinationPath);
		} catch (IOException e) {
			fail("Unable to reset files");
		}
	}
	
	/**
	 * test add course to catalog
	 */
	@Test
	public void testAddCourseToCatalog(){
		CourseCatalog c = new CourseCatalog();
		c.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, MEETING_DAYS, START_TIME, END_TIME);
		
		assertFalse(c.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, MEETING_DAYS, START_TIME, END_TIME));
	}
	
	/**
	 * test remove course to catalog
	 */
	@Test
	public void removeCourseFromCatalog(){
		CourseCatalog c = new CourseCatalog();
		c.removeCourseFromCatalog(NAME, SECTION);
		
		assertFalse(c.removeCourseFromCatalog(NAME, SECTION));
	}

	/**
	 * test new Course catalog
	 */
	@Test
	public void newCourseCatalog(){
		CourseCatalog c = new CourseCatalog();
		
		c.loadCoursesFromFile(validTestFile);
		assertEquals(13, c.getCourseCatalog().length);
		
		assertEquals(13, c.getCourseCatalog().length);
	}
	
	/**
	 * Tests remove course from catalog.
	 */
	@Test
	public void testRemoveCourseFromCatalog2() {
		CourseCatalog c = new CourseCatalog();
				
		c.loadCoursesFromFile(validTestFile);
		assertEquals(13, c.getCourseCatalog().length);
		assertTrue(c.removeCourseFromCatalog("CSC 230", "001"));
		assertEquals(12, c.getCourseCatalog().length);
	}

	/**
	 * Tests save course catalog .
	 */
	@Test
	public void testSaveCourseCatalog() {
		CourseCatalog c = new CourseCatalog();
	
		c.addCourseToCatalog("CSC 230", TITLE, "004", CREDITS, INSTRUCTOR_ID, "W", START_TIME, END_TIME);
		assertEquals(1, c.getCourseCatalog().length);
		c.saveCourseCatalog("test-files/actual_student_records.txt");
	}
	
}
