package edu.ncsu.csc216.pack_scheduler.users;


import static org.junit.jupiter.api.Assertions.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import edu.ncsu.csc216.pack_scheduler.directory.StudentDirectory;
import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.user.User;

/**
 * Tests the Student object.
 * @author SarahHeckman and Xufeng Ce
 * @author Shiv Patel
 */
public class StudentTest {
	
	/** Test Student's first name. */
	private String firstName = "first";
	/** Test Student's last name */
	private String lastName = "last";
	/** Test Student's id */
	private String id = "flast";
	/** Test Student's email */
	private String email = "first_last@ncsu.edu";
	/** Test Student's hashed password */
	private String hashPW;
	/** Hashing algorithm */
	private static final String HASH_ALGORITHM = "SHA-256";
	
	//This is a block of code that is executed when the StudentTest object is
	//created by JUnit.  Since we only need to generate the hashed version
	//of the plaintext password once, we want to create it as the StudentTest object is
	//constructed.  By automating the hash of the plaintext password, we are
	//not tied to a specific hash implementation.  We can change the algorithm
	//easily.
	{
		try {
			String plaintextPW = "password";
			MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
			digest.update(plaintextPW.getBytes());
			this.hashPW = Base64.getEncoder().encodeToString(digest.digest());
		} catch (NoSuchAlgorithmException e) {
			fail("An unexpected NoSuchAlgorithmException was thrown.");
		}
	}
	/**
	 * Tests constructing a Student.
	 */
	@Test
	public void testStudent() {
		// Test a valid construction
		User c = assertDoesNotThrow(
				() -> new Student(firstName, lastName, id, email, hashPW),
				"Should not throw exception");

		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));
	}
	/**
	 * Tests setFirstName().
	 */
	@Test
	public void testSetFirstNameValid() {
		User c = new Student(firstName, lastName, id, email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));

		// Test valid first name
		c.setFirstName("Xufeng");
		assertAll("Student", 
				() -> assertEquals("Xufeng", c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));
	}
	/**
	 * Tests setFirstNameInvalid with invalid input.
	 * @param invalid invalid input for the test
	 */
	@ParameterizedTest
	@NullAndEmptySource
	public void testSetFirstNameInvalid(String invalid) {
		User c = new Student(firstName, lastName, id, email, hashPW);

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> c.setFirstName(invalid));
		assertEquals("Invalid first name", exception.getMessage(), "Incorrect exception thrown with invalid input - " + invalid);
	}
	/**
	 * Tests setLastName().
	 */
	@Test
	public void testSetLastNameValid() {
		User c = new Student(firstName, lastName, id, email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));

		// Test valid last name
		c.setLastName("Ce");
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals("Ce", c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));
	}
	/**
	 * Tests setLastNameInvalid with invalid input.
	 * @param invalid invalid input for the test
	 */
	@ParameterizedTest
	@NullAndEmptySource
	public void testSetLastNameInvalid(String invalid) {
		User c = new Student(firstName, lastName, id, email, hashPW);

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> c.setLastName(invalid));
		assertEquals("Invalid last name", exception.getMessage(), "Incorrect exception thrown with invalid input - " + invalid);
	}
	/**
	 * Tests setId().
	 */
	@Test
	public void testSetIdValid() {
		User c = new Student(firstName, lastName, id, email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));

		// Test valid id
		User a = new Student(firstName, lastName, "xce", email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, a.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, a.getLastName(), "incorrect lastName"),
				() -> assertEquals("xce", a.getId(), "incorrect id"), 
				() -> assertEquals(email, a.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, a.getPassword(), "incorrect password"));
	}
	/**
	 * Tests setIdInvalid with invalid input.
	 * @param invalid invalid input for the test
	 */
	@ParameterizedTest
	@NullAndEmptySource
	public void testSetIdInvalid(String invalid) {
		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> new Student(firstName, lastName, invalid, email, hashPW));
		assertEquals("Invalid id", exception.getMessage(), "Incorrect exception thrown with invalid input - " + invalid);
	}
	/**
	 * Tests setEmail().
	 */
	@Test
	public void testSetEmailValid() {
		User c = new Student(firstName, lastName, id, email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));

		// Test valid email
		c.setEmail("xce@ncsu.edu");
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals("xce@ncsu.edu", c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));
	}
	/**
	 * Tests setEmail with invalid input.
	 * @param invalid invalid input for the test
	 */
	@ParameterizedTest
	@NullAndEmptySource
	@ValueSource(strings = {"orci.Donec@ametmassaQuisquecom", "orciDonec@ametmassaQuisquecom", "orci.DonecametmassaQuisque.com"})
	public void testSetEmailInvalid(String invalid) {
		User c = new Student(firstName, lastName, id, email, hashPW);

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> c.setEmail(invalid));
		assertEquals("Invalid email", exception.getMessage(), "Incorrect exception thrown with invalid input - " + invalid);
	}
	/**
	 * Tests setPassword().
	 */
	@Test
	public void testSetPasswordValid() {
		User c = new Student(firstName, lastName, id, email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"));

		// Test valid password
		c.setPassword("Womingzi2@");
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals("Womingzi2@", c.getPassword(), "incorrect password"));
	}
	/**
	 * Tests setPassword with invalid input.
	 * @param invalid invalid input for the test
	 */
	@ParameterizedTest
	@NullAndEmptySource
	public void testSetPasswordInvalid(String invalid) {
		User c = new Student(firstName, lastName, id, email, hashPW);

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> c.setPassword(invalid));
		assertEquals("Invalid password", exception.getMessage(), "Incorrect exception thrown with invalid input - " + invalid);
	}
	/**
	 * Tests setMaxCredits().
	 */
	@Test
	public void testSetMaxCreditsValid() {
		Student c = new Student(firstName, lastName, id, email, hashPW);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"),
				() -> assertEquals(18, c.getMaxCredits(), "incorrect max credits"));

		// Test valid password
		c.setMaxCredits(15);
		assertAll("Student", 
				() -> assertEquals(firstName, c.getFirstName(), "incorrect firstName"), 
				() -> assertEquals(lastName, c.getLastName(), "incorrect lastName"),
				() -> assertEquals(id, c.getId(), "incorrect id"), 
				() -> assertEquals(email, c.getEmail(), "incorrect email"),
				() -> assertEquals(hashPW, c.getPassword(), "incorrect password"),
				() -> assertEquals(15, c.getMaxCredits(), "incorrect max credits"));
	}
	/**
	 * Tests setMaxCredits with invalid input.
	 * @param invalid invalid input for the test
	 */
	@ParameterizedTest
	@ValueSource(ints = {2, 19})
	public void testSetMaxCreditsInvalid(int invalid) {
		Student c = new Student(firstName, lastName, id, email, hashPW);

		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> c.setMaxCredits(invalid));
		assertEquals("Invalid max credits", exception.getMessage(), "Incorrect exception thrown with invalid input - " + invalid);
	}
	
	
	/**
	 * Tests that the equals method works for all Student fields.
	 */
	@SuppressWarnings("unlikely-arg-type")
	@Test
	public void testEqualsObject() {
		User c1 = new Student(firstName, lastName, id, email, hashPW);
		User c2 = new Student(firstName, lastName, id, email, hashPW);
		
		User c3 = new Student("Different", lastName, id, email, hashPW);
		User c4 = new Student(firstName, "Different", id, email, hashPW);
		User c5 = new Student(firstName, lastName, "Different", email, hashPW);
		User c6 = new Student(firstName, lastName, id, "xce@ncsu.edu", hashPW);
		User c7 = new Student(firstName, lastName, id, email, "Different");

		User c8 = new Student(firstName, lastName, id, email, hashPW, 15);
		User c9 = c1;
		StudentDirectory c10 = new StudentDirectory();

		// Test for equality in both directions
		assertTrue(c1.equals(c2));
		assertTrue(c2.equals(c1));
		assertTrue(c1.equals(c9));
		
		// Test for each of the fields
		assertFalse(c1.equals(c3));
		assertFalse(c1.equals(c4));
		assertFalse(c1.equals(c5));
		assertFalse(c1.equals(c6));
		assertFalse(c1.equals(c7));
		assertFalse(c1.equals(c8));
		assertFalse(c1.equals(c10));

	}
	/**
	 * Tests that hashCode works correctly.
	 */
	@Test
	public void testHashCode() {
		User c1 = new Student(firstName, lastName, id, email, hashPW);
		User c2 = new Student(firstName, lastName, id, email, hashPW);
		
		User c3 = new Student("Different", lastName, id, email, hashPW);
		User c4 = new Student(firstName, "Different", id, email, hashPW);
		User c5 = new Student(firstName, lastName, "Different", email, hashPW);
		User c6 = new Student(firstName, lastName, id, "xce@ncsu.edu", hashPW);
		User c7 = new Student(firstName, lastName, id, email, "Different");


		// Test for the same hash code for the same values
		assertEquals(c1.hashCode(), c2.hashCode());

		// Test for each of the fields
		assertNotEquals(c1.hashCode(), c3.hashCode());
		assertNotEquals(c1.hashCode(), c4.hashCode());
		assertNotEquals(c1.hashCode(), c5.hashCode());
		assertNotEquals(c1.hashCode(), c6.hashCode());
		assertNotEquals(c1.hashCode(), c7.hashCode());
	}
	/**
	 * Test toString() method.
	 */
	@Test
	public void testToString() {
		User s1 = new Student(firstName, lastName, id, email, hashPW);
		assertEquals("first,last,flast,first_last@ncsu.edu," + hashPW + ",18", s1.toString());
	}
	/**
	 * Test if the lastName, firstName, or id is in sorted order
	 */
	@Test
	public void testCompareTo() {
		Student c1 = new Student("Xufeng", "Ce", "xce", email, hashPW);
		Student c2 = new Student("Xufeng", "Ae", "xae", email, hashPW);
		
		Student c3 = new Student("Jake", "Smith", "jsmith", email, hashPW);
		Student c4 = new Student("Dave", "Smith", "dsmith", email, hashPW);
		
		Student c5 = new Student("Jake", "Turner", "jturner", email, hashPW);
		Student c6 = new Student("Jake", "Turner", "dturner", "xce@ncsu.edu", hashPW);

		Student c7 = new Student("Jake", "Turner", "dturner", email, hashPW);
		Student c8 = null;
		

		assertEquals(1, c1.compareTo(c2));
		assertEquals(1, c3.compareTo(c4));
		assertEquals(1, c5.compareTo(c6));
		
		assertEquals(-1, c2.compareTo(c1));
		assertEquals(-1, c4.compareTo(c3));
		assertEquals(-1, c6.compareTo(c5));
		
		assertEquals(0, c6.compareTo(c7));
		

		
		try {
			c1.compareTo(c8);
			fail();
		} catch (NullPointerException e){
			//
		}

	}

}
