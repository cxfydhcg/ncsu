package edu.ncsu.csc217.collections.list;

import static org.junit.Assert.*;
import org.junit.Test;
/**
 * Test sorted list and test add, get, remove, indexOf, clear, 
 * isEmpty, contains, equals and hashCode method
 * @author Xufeng Ce
 * @author Shiv Patel
 */
public class SortedListTest {
	/**
	 * test SortedList for growing correctly
	 */
	@Test
	public void testSortedList() {
		SortedList<String> list = new SortedList<String>();
		assertEquals(0, list.size());
		assertFalse(list.contains("apple"));
		assertTrue(list.isEmpty());
		
		for (int i = 0; i < 12; i++) {
			String a = "" + i;
			list.add(a);
		}
		assertEquals(12, list.size());
	}
	/**
	 * Test add element to list
	 */
	@Test
	public void testAdd() {
		SortedList<String> list = new SortedList<String>();
		
		list.add("banana");
		assertEquals(1, list.size());
		assertEquals("banana", list.get(0));
		
		// Test adding to the front, middle and back of the list
		list.add("a");
		list.add("g");
		list.add("d");
		assertEquals("a", list.get(0));
		assertEquals("d", list.get(2));
		assertEquals("g", list.get(3));
		// Test adding a null element
		try {
			list.add(null);
		} catch (NullPointerException e) {
			assertEquals(4, list.size());
		}
		// Test adding a duplicate element
		try {
			list.add("a");
		} catch (IllegalArgumentException e) {
			assertEquals(4, list.size());
		}
	}
	
	/**
	 * Tests the get elements from the list
	 */
	@Test
	public void testGet() {
		SortedList<String> list = new SortedList<String>();
		
		//Since get() is used throughout the tests to check the
		//contents of the list, we don't need to test main flow functionality
		//here.  Instead this test method should focus on the error 
		//and boundary cases.
		
		// Test getting an element from an empty list
		try {
			list.get(0);
			fail();
		}
		catch(IndexOutOfBoundsException e) {
			//
		}
		
		// Add some elements to the list
		list.add("Apple");
		list.add("Bee");
		list.add("Car");
		list.add("Egg");
		// Test getting an element at an index < 0
		try {
			list.get(-1); 
			fail();
		} catch(IndexOutOfBoundsException e) {
			//
		}
		
		// Test getting an element at size
		try {
			list.get(list.size());
			fail();
		} catch(IndexOutOfBoundsException e) {
			//
		}
		
	}
	/**
	 * Test SortList.remove method
	 */
	@Test
	public void testRemove() {
		SortedList<String> list = new SortedList<String>();
		
		// Test removing from an empty list
		try {
			list.remove(0);
			fail();
		} catch (IndexOutOfBoundsException e) {
			//
		}
		// Add some elements to the list - at least 4
		list.add("Apple");
		list.add("Bee");
		list.add("Car");
		list.add("Egg");
		// Test removing an element at an index < 0
		try {
			list.remove(-1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			//
		}
		// Test removing an element at size
		try {
			list.remove(list.size());
			fail();
		} catch (IndexOutOfBoundsException e) {
			//
		}
		// Test removing a middle element
		assertEquals("Car", list.remove(2));
		// Test removing the last element
		assertEquals("Egg", list.remove(list.size() - 1));
		// Test removing the first element
		assertEquals("Apple", list.remove(0));
		// Test removing the last element
		assertEquals("Bee", list.remove(list.size() - 1));
	}
	/**
	 * Test SortList.indexof method
	 */
	@Test
	public void testIndexOf() {
		SortedList<String> list = new SortedList<String>();
		
		// Test indexOf on an empty list
		assertEquals(-1, list.indexOf("Qqq"));
		// Add some elements
		list.add("Apple");
		list.add("Bee");
		list.add("Car");
		list.add("Egg");
		// Test various calls to indexOf for elements in the list
		assertEquals(0, list.indexOf("Apple"));
		assertEquals(2, list.indexOf("Car"));
		assertEquals(3, list.indexOf("Egg"));
		assertEquals(1, list.indexOf("Bee"));
		//and not in the list
		assertEquals(-1, list.indexOf("Qqq"));
		// Test checking the index of null
		try {
			list.indexOf(null);
		} catch (NullPointerException e) {
			//
		}
	}
	
	/**
	 * Test SortList.clear method
	 */
	@Test
	public void testClear() {
		SortedList<String> list = new SortedList<String>();

		// Add some elements
		list.add("Apple");
		list.add("Bee");
		list.add("Car");
		list.add("Egg");
		// Clear the list
		list.clear();
		assertEquals(0, list.size());
		
		// Test that the list is empty
	}

	/**
	 * Test SortList.isEmpty method
	 */
	@Test
	public void testIsEmpty() {
		SortedList<String> list = new SortedList<String>();
		
		// Test that the list starts empty
		assertEquals(0, list.size());
		assertTrue(list.isEmpty());
		// Add at least one element
		list.add("Apple");
		// Check that the list is no longer empty
		assertFalse(list.isEmpty());
	}
	/**
	 * test if the SortedList contain an element
	 */
	@Test
	public void testContains() {
		SortedList<String> list = new SortedList<String>();
		
		// Test the empty list case
		assertFalse(list.contains("a"));
		// Add some elements
		list.add("Apple");
		list.add("Bee");
		list.add("Car");
		list.add("Egg");
		// Test some true and false cases
		assertTrue(list.contains("Apple"));
		assertFalse(list.contains("a"));
		
	}
	
	/**
	 * Test the sortedList Equals method
	 */
	@Test
	public void testEquals() {
		SortedList<String> list1 = new SortedList<String>();
		list1.add("Apple");
		list1.add("Bee");
		list1.add("Car");
		SortedList<String> list2 = new SortedList<String>();
		list2.add("Apple");
		list2.add("Bee");
		list2.add("Car");
		SortedList<String> list3 = new SortedList<String>();
		list3.add("Apple");
		list3.add("Bee");
		list3.add("Egg");

		assertTrue(list1.equals(list2));
		assertFalse(list2.equals(list3));
		
	}
	/**
	 * Tests that hashCode works correctly.
	 */
	@Test
	public void testHashCode() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();
		
		// Make two lists the same and one list different
		list1.add("Apple");
		list1.add("Bee");
		list1.add("Car");
		list1.add("Egg");
		
		list2.add("Apple");
		list2.add("Bee");
		list2.add("Car");
		list2.add("Egg");
		
		list3.add("Apple");
		list3.add("Bee");
		list3.add("Car");
		list3.add("Egg");
		list3.add("Day");
		
		// Test for the same and different hashCodes
		assertEquals(list1.hashCode(), list2.hashCode());
		assertNotEquals(list1.hashCode(), list3.hashCode());
		assertNotEquals(list2.hashCode(), list3.hashCode());
	}

}
 