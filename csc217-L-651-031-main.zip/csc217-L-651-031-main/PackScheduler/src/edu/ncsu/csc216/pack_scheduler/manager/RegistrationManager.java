package edu.ncsu.csc216.pack_scheduler.manager;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import edu.ncsu.csc216.pack_scheduler.catalog.CourseCatalog;
import edu.ncsu.csc216.pack_scheduler.directory.StudentDirectory;
import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.user.User;
/**
 * Registration manager class handles login or logout of registrar get student's information or course' information
 * @author Xufeng Ce
 *
 */
public class RegistrationManager {
	/** instance of RegistrantionManager */
	private static RegistrationManager instance;
	/** Registration manager's course catalog */
	private CourseCatalog courseCatalog;
	/** Registration manager's student directory */
	private StudentDirectory studentDirectory;
	/** registrar's user  */
	private User registrar;
	/** current user */
	private User currentUser;
	/** Hashing algorithm */
	private static final String HASH_ALGORITHM = "SHA-256";
	/** registrar's information */
	private static final String PROP_FILE = "registrar.properties";

	/**
	 * Registration manager constructor 
	 */
	private RegistrationManager() {
		createRegistrar();
		this.courseCatalog = new CourseCatalog();
		this.studentDirectory = new StudentDirectory();
		this.registrar = new Registrar("Xufeng", "Ce", "xce", "xce@ncsu.edu", hashPW("Woming"));
	}
	
	/**
	 * create a new registrar
	 */
	private void createRegistrar() {
		Properties prop = new Properties();
		
		try (InputStream input = new FileInputStream(PROP_FILE)) {
			prop.load(input);
			
			String hashPW = hashPW(prop.getProperty("pw"));
			
			registrar = new Registrar(prop.getProperty("first"), prop.getProperty("last"), prop.getProperty("id"), prop.getProperty("email"), hashPW);
		} catch (IOException e) {
			throw new IllegalArgumentException("Cannot create registrar.");
		}
	}
	/**
	 * hash the password using "SHA-256" algorithm
	 * @param pw password of the user
	 * @return hashed password
	 */
	private String hashPW(String pw) {
		try {
			MessageDigest digest1 = MessageDigest.getInstance(HASH_ALGORITHM);
			digest1.update(pw.getBytes());
			return Base64.getEncoder().encodeToString(digest1.digest());
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalArgumentException("Cannot hash password");
		}
	}
	/**
	 * checks for and creates and instance of RegistrarionManager
	 * @return instance of RegostrationManger
	 */
	public static RegistrationManager getInstance() {
		  if (instance == null) {
			instance = new RegistrationManager();
		}
		return instance;
	}
	/**
	 * get registrationManager's course catalog
	 * @return registrationManager's CourseCatalog
	 */
	public CourseCatalog getCourseCatalog() {
		return courseCatalog;
	}
	/**
	 * get registrationManager's studentDirectory
	 * @return registrationManager's studentDirectory
	 */
	public StudentDirectory getStudentDirectory() {
		return studentDirectory;
	}

	/**
	 * logs a user into the registration system
	 * @param id id of user to be logged in
	 * @param password password of user to be logged in 
	 * @return true if the user is able to be logged in to the system, false otherwise
	 */
	public boolean login(String id, String password) {
		Student s = studentDirectory.getStudentById(id);
		
		
		String localHashPW = hashPW(password);
		if (s.getPassword().equals(localHashPW)) {
			currentUser = s;
				return true;
		}	
		
		if (registrar.getId().equals(id)) {
				
			if (registrar.getPassword().equals(localHashPW)) {
				currentUser = registrar;
					return true;
			}
		}
			
				return false;
	}
	/**
	 * log a user out of the system
	 */
	public void logout() {
		currentUser = null; 
	}
	
	/**
	 * get the user currently logged in to the system
	 * @return  current user of registrationManager
	 */
	public User getCurrentUser() {
		return currentUser;
	}
	/**
	 * clear the information in the registration manager, leaving an empty
	 * course catalog and empty student directory
	 */
	public void clearData() {
		courseCatalog.newCourseCatalog();
		studentDirectory.newStudentDirectory();
	}
	/**
	 * Registrar inner class
	 * @author Xufeng Ce
	 *
	 */
	private static class Registrar extends User {
		/**
		 * Create a registrar user.
		 * 
		 * @param firstName firstName of registrar
		 * @param lastName lastName of registrar
		 * @param id id of registrar
		 * @param email email of registrar
		 * @param hashPW hash password of registrar
		 */
		public Registrar(String firstName, String lastName, String id, String email, String hashPW) {
			super(firstName, lastName, id, email, hashPW);
		}

	}
}