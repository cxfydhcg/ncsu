package edu.ncsu.csc216.pack_scheduler.user;
/**
 * user object to be used in the PackScheduler Contains a 
 * User's first name, last name, id, email, and password
 * information in this project
 * 
 * @author Xufeng Ce
 * 
 * */


public abstract class User {
	
	
	/** Student's firstName */
	private String firstName;
	/** Student's lastName */
	private String lastName;
	/** Student's id */
	private String id;
	/** Student's email */
	private String email;
	/** Student's password */
	private String password;

	
	
	/**
	 * Constructs a User object with values for all fields.
	 * @param firstName firstName of User
	 * @param lastName lastName of User
	 * @param id id of User
	 * @param email email of User
	 * @param hashPW hashPW of User
	 */
	
	public User(String firstName, String lastName, String id, String email, String hashPW) {
		setFirstName(firstName);
		setLastName(lastName);
		setId(id);
		setEmail(email);
		setPassword(hashPW);

	}


	/**
	 * get the user's first name
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * set the usert's first name
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		if(firstName == null || "".equals(firstName)) {
			throw new IllegalArgumentException("Invalid first name");
		}
		
		this.firstName = firstName;
	}

	/**
	 * get the user's last name
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * set the user's last name
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		if(lastName == null || "".equals(lastName)) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		this.lastName = lastName;
	}

	/**
	 * get the user's id
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * set the user's id
	 * @param id the id to set
	 */
	protected void setId(String id) {
		if(id == null || "".equals(id)) {
			throw new IllegalArgumentException("Invalid id");
		}
		
		this.id = id;
	}

	/**
	 * get the user's email
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * set the user's email
	 * @param email the email to set
	 */
	public void setEmail(String email) {

		
		if(email == null || "".equals(email)) {
			throw new IllegalArgumentException("Invalid email");
		}
		if(!email.contains("@") || !email.contains(".")) {
			throw new IllegalArgumentException("Invalid email");
		}
		
		if(email.indexOf('@') > email.lastIndexOf('.')) {
			throw new IllegalArgumentException("Invalid email");
		}
		this.email = email;
	}

	/**
	 * get the user's password
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * set the user's password
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		if(password == null || "".equals(password)) {
			throw new IllegalArgumentException("Invalid password");
		}
		
		this.password = password;
	}
	
	/**
	 * Returns a comma separated value String of all User fields.
	 * @return String representation of User
	 */
	
	@Override
	public String toString() {
		return firstName + "," + lastName + "," + id + "," + email + "," + password + ",";
	}

	/**
	 *	Generates a hashCode for User using all fields.
	 * @return hashCode for User
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	/**
	 * Compares a given object to this object for equality on all fields.
	 * @param obj the Object to compare
	 * @return true if the objects are the same on all fields.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	
}
