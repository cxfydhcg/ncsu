/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user;

/**
 * Student object to be used in the PackScheduler Contains a 
 * Studnet's first name, last name, id, email, password, and max credits
 * information in this project
 * @author Xufeng
 *
 */
public class Student extends User implements Comparable<Student> {
	/** Student's max credits and minimum credits */
	public static final int MAX_CREDITS = 18,
							MIN_CREDITS = 3;
	/** Student's max credit*/
	private int maxCredits;
	
	
	/**
	 * Constructs a Student object with values for all fields.
	 * @param firstName firstName of Student
	 * @param lastName lastName of Student
	 * @param id id of Student
	 * @param email email of Student
	 * @param hashPW hashPW of Student
	 * @param maxCredits maxCredits of Student
	 */
	
	public Student(String firstName, String lastName, String id, String email, String hashPW, int maxCredits) {
		super(firstName, lastName, id, email, hashPW);
		setMaxCredits(maxCredits);

	}
	
	/**
	 * Constructs a Student object with values for all fields.
	 * @param firstName firstName of Student
	 * @param lastName lastName of Student
	 * @param id id of Student
	 * @param email email of Student
	 * @param hashPW hashPW of Student
	 */
	
	public Student(String firstName, String lastName, String id, String email, String hashPW) {
		this(firstName, lastName, id, email, hashPW, MAX_CREDITS);
	}
	
	
	/**
	 * get the student's max credits
	 * @return the maxCredits
	 */
	public int getMaxCredits() {
		return maxCredits;
	}

	/**
	 * set the student's max credits
	 * @param maxCredits the maxCredits to set
	 */
	public void setMaxCredits(int maxCredits) {
		
		if(maxCredits < MIN_CREDITS || maxCredits > MAX_CREDITS) {
			throw new IllegalArgumentException("Invalid max credits");
		}
		
		this.maxCredits = maxCredits;
	}

	/**
	 *	Generates a hashCode for Student using all fields.
	 * @return hashCode for Student
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + maxCredits;
		return result;
	}

	/**
	 * Compares a given object to this object for equality on all fields.
	 * @param obj the Object to compare
	 * @return true if the objects are the same on all fields.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (maxCredits != other.maxCredits)
			return false;
		return true;
	}

	/**
	 * Returns a comma separated value String of all Student fields.
	 * @return String representation of Student
	 */
	
	@Override
	public String toString() {
		return getFirstName() + "," + getLastName() + "," + getId() + "," + getEmail() + "," + getPassword() + "," + this.maxCredits;
	}

	/**
	 * return - as this object is less than,
	 * 		 = as this object is equal to,
	 * 		 + as this object is greater to
	 */
	@Override
	public int compareTo(Student s) {
		
		if(s == null) {
			throw new NullPointerException();
		}
		if(this.getClass() != s.getClass()) {
			throw new ClassCastException();
		}
		
		if(this.getLastName().compareTo(s.getLastName()) < 0) {
			return -1;
		} else if (this.getLastName().compareTo(s.getLastName()) > 0) {
			return 1;
		} else {
			
			if (this.getFirstName().compareTo(s.getFirstName()) < 0) {
				return -1;
			} else if(this.getFirstName().compareTo(s.getFirstName()) > 0){
				return 1;
			} else {
				if (this.getId().compareTo(s.getId()) < 0) {
					return -1;
				} else if(this.getId().compareTo(s.getId()) > 0){
					return 1;
				} else {
					return 0;
				}
			}
			
		}
		
	}



}
