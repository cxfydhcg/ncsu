/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.catalog;

import java.io.FileNotFoundException;
import java.io.IOException;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.io.CourseRecordIO;

import edu.ncsu.csc217.collections.list.SortedList;

/**
 * Maintains a directory of all courses at NC State.
 * All courses have a unique name or section.
 * @author sbpatel6
 * @author Xufeng Ce
 */
public class CourseCatalog {
	/** SortedList for Course */
	private SortedList<Course> catalog;
	
	/**
	 * Creates an empty course directory
	 */
	public CourseCatalog() {
		newCourseCatalog();
	}
	
	/**
	 * Creates an empty course directory.  All courses in the previous
	 * list are list unless saved by the user.
	 */
	public void newCourseCatalog() {
		catalog = new SortedList<Course>();
	}
	
	/**
	 * Constructs the student directory by reading in student information
	 * from the given file.  Throws an IllegalArgumentException if the 
	 * file cannot be found.
	 * @param fileName file containing list of students
	 */
	public void loadCoursesFromFile(String fileName) {
		try {
			catalog = CourseRecordIO.readCourseRecords(fileName);
		} catch(FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to read file" + fileName);
		}
	}
	
	
	/**
	 * Adds a course to the directory.
	 * @param name name of Course
	 * @param title title of Course
	 * @param section section of Course
	 * @param credits credit hours for Course
	 * @param instructorId instructor's unity id
	 * @param meetingDays meeting days for Course as series of chars
	 * @param startTime start time for Course
	 * @param endTime end time for Course
	 * @return returns true if the course is added and false if
	 * the course is unable to be added because its already in the catalog.
	 */
	public boolean addCourseToCatalog(String name, String title, String section, int credits, String instructorId, String meetingDays,
	        int startTime, int endTime) {
		Course course = new Course (name, title, section, credits, instructorId, meetingDays, startTime, endTime);
		for(int i = 0; i < catalog.size(); i++) {
			Course c = catalog.get(i);
			if(c.getName().equals(course.getName()) && c.getSection().equals(course.getSection())) {
				return false;
			}
		}
		catalog.add(course);
		// return true if the course can be added
		return true;
		
	}
	
	/**
	 * Removes the course with the given name and section from the list
	 * @param name course's name
	 * @param section course's section
	 * @return returns true if the student is removed and false if the student is not in the list.
	 */
	public boolean removeCourseFromCatalog(String name, String section) {
		for (int i = 0; i < catalog.size(); i++) {
			Course s = catalog.get(i);
			if (s.getName().equals(name) && s.getSection().equals(section)) {
				catalog.remove(i);
				return true;
			}
		}
		return false;
	}
	/**
	 * get Course from the Catalog
	 * @param name course's name
	 * @param section course's section
	 * @return return Course if it is in the catalog
	 * 				null if the Course isn't in the catalog
	 */
	public Course getCourseFromCatalog(String name, String section) {
		for (int i = 0; i < catalog.size(); i++) {
			Course s = catalog.get(i);
			if (s.getName().equals(name) && s.getSection().equals(section)) {
				return catalog.get(i);
			}
		}
		return null;
	}
	/**
	 * Returns all courses in the directory with a column for first name, last name, and id.
	 * @return String array containing course's name, section and title.
	 */
	public String[][] getCourseCatalog() {
		//catalog.get(0);
		String [][] catalogs = new String[catalog.size()][4];
		for (int i = 0; i < catalog.size(); i++) {
			Course s = catalog.get(i);
			catalogs[i][0] = s.getName();
			catalogs[i][1] = s.getSection();
			catalogs[i][2] = s.getTitle();
			catalogs[i][3] = s.getMeetingString();
		}
		return catalogs;
	}
	
	/**
	 * Saves all courses from the catalog into a file.
	 * @param fileName name of file to save students to.
	 */
	public void saveCourseCatalog(String fileName) {
		try {
			CourseRecordIO.writeCourseRecords(fileName, catalog);
		} catch (IOException e) {
			throw new IllegalArgumentException("Unable to write to file " + fileName);
		}
	}

}
