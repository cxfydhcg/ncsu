/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Check the conflict for activity
 * @author Xufeng Ce
 * @author Shiv Patel
 */


public interface Conflict {
	/**
	 * Create a custom conflict exception
	 * @param possibleConflictingActivity is a conflicting activity
	 * @throws ConflictException if there are any conflicts
	 */
	void checkConflict(Activity possibleConflictingActivity) throws ConflictException;

}
