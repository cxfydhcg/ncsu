package edu.ncsu.csc216.pack_scheduler.io;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import java.io.PrintWriter;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.pack_scheduler.user.Student;

import edu.ncsu.csc217.collections.list.SortedList;


/**
 * Reads Student records from text files.  Writes a set of StudentRecords to a file.
 * @author Xufeng Ce 
 * @author Shiv Patel
 *
 */
public class StudentRecordIO {


	/**
     * Reads student records from a file and generates a list of valid students.  Any invalid
     * Students are ignored.  If the file to read cannot be found or the permissions are incorrect
     * a File NotFoundException is thrown.
     * @param fileName file to read Student records from
     * @return a list of valid Students
     * @throws FileNotFoundException if the file cannot be found or read
     */
	public static SortedList<Student> readStudentRecords(String fileName) throws FileNotFoundException {

		Scanner fileReader = new Scanner(new FileInputStream(fileName));  //Create a file scanner to read the file
	    SortedList<Student> students = new SortedList<Student>(); //Create an empty array of Student objects
	    while (fileReader.hasNextLine()) { //While we have more lines in the file
	        try { //Attempt to do the following
	            //Read the line, process it in processStudent, and get the object
	            //If trying to construct a Student in processStudent() results in an exception, flow of control will transfer to the catch block, below
	             students.add(processStudent(fileReader.nextLine())); 

	            //Create a flag to see if the newly created Student is a duplicate of something already in the list  
	           
	        } catch (IllegalArgumentException e) {
	            //The line is invalid b/c we couldn't create a student, skip it!
	        }
	    }
	    //Close the Scanner b/c we're responsible with our file handles
	    fileReader.close();
	    return students;
	}

	/**
	 * Read student record from a file, check out the student format, if format wrong throw IAE
     * @throws IllegalArgumentException if the student information is wrong or format is wrong in read file
	 * @param nextLine read the student info record in the file
	 * @return Student Student object
	 */

	private static Student processStudent(String nextLine) {
		//construct Scanner to process the nextLine parameter
		Scanner scan = new Scanner(nextLine);
		scan.useDelimiter(",");
		
		Student s = null;
			try {
				String firstName = scan.next();
				String lastName = scan.next();
				String id = scan.next();
				String email = scan.next();
				String password = scan.next();
				int maxCredits = scan.nextInt();
				
				s = new Student(firstName, lastName, id, email, password, maxCredits);

			} catch (NoSuchElementException e) {
				scan.close();
				throw new IllegalArgumentException("Invalid student infomation.");
			}
		scan.close();
		return s;
	}
	
	/**
	 * Writes the given list of Students to a new file
	 * @param fileName file to write Student records
	 * @param studentDirectory directory from which to pull information to write
	 * @throws IOException if the file cannot be written
	 */
	public static void writeStudentRecords(String fileName, SortedList<Student> studentDirectory) throws IOException {
		PrintWriter fileWriter = new PrintWriter(new FileWriter(fileName));
		for (int i = 0; i < studentDirectory.size(); i++) {

		    fileWriter.println(studentDirectory.get(i).toString());
		}

		fileWriter.close();
		
	}

}